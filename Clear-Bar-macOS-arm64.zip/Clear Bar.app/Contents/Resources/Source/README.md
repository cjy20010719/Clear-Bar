<p align="center"><img src="AppIcon.png" width="112" alt="Clear Bar icon"></p>

# Clear Bar

让壁纸自然延伸到 macOS 菜单栏。一个轻量后台应用，同时管理多块屏幕的壁纸与透明菜单栏。

## 下载

下载仓库中的 **[Clear-Bar-macOS-arm64.zip](Clear-Bar-macOS-arm64.zip)**，解压后打开 `Clear Bar.app`。

当前提供 Apple Silicon 版本，要求 macOS 14 Sonoma 或更新版本。发布包采用本地签名，未经 Apple 公证；也可以使用下方脚本自行从源码构建。已在一台搭载 Sonoma 的 Apple Silicon 双屏 Mac 上使用，未覆盖所有系统和显示器组合。

## 功能

- 同一个进程管理全部连接的屏幕。
- 更换一张壁纸，自动按每块屏幕的比例、分辨率和缩放适配。
- 批量添加壁纸，点缩略图或“下一张”即可切换。
- 400 点宽的磨砂玻璃面板，无系统标题栏。
- 右上角 × 或 Esc 只收起面板，后台效果继续运行。
- 暂停或正常退出时，恢复当前壁纸的原图。
- 睡眠唤醒、屏幕插拔、分辨率变化和切换空间后重新适配。

## 使用

1. 打开 `Clear Bar.app`，点击 **更换壁纸** 选择静态 JPG 或 PNG。
2. 想一键循环切换时，先用 **添加多张** 建立壁纸库。
3. 在右上角 **⋯** 或菜单栏矩形图标中，可以暂停效果、重新打开面板或退出。

应用会复制导入的原图到本地壁纸库。下载文件被移动后，已导入的壁纸仍可使用。

### 透明效果如何工作

Clear Bar 根据原图生成各屏幕专用的壁纸，再用菜单栏覆层完成视觉混合。这是壁纸模拟透明，需要应用在后台运行；彻底退出后会恢复原图。系统的 **降低透明度** 应保持关闭，应用不会替你修改该设置。

仅支持静态 JPG、PNG；不支持视频、航拍或动态壁纸。应用通过菜单栏窗口绘制效果，使用了未公开的 Core Animation 接口，未来 macOS 更新可能影响效果。使用时请退出原版 Clear Menu Bar 和旧副屏补充工具，避免覆层重叠。

未设置开机启动。重启电脑后需重新打开应用。

### 恢复

优先选择 **⋯ → 退出并恢复原图**。如果强制结束进程后留下黑条，可重新打开应用再正常退出，或到系统设置的墙纸面板重新选择原图。

本地壁纸库和处理图位于：

```text
~/Library/Application Support/TransparentMenuBar/
```

应用不联网，不监听全局键盘，不申请屏幕录制权限。仓库和下载包不包含用户的壁纸、偏好设置或运行日志。

## 从源码构建

需要 Xcode Command Line Tools、Swift 和 Python 3。当前构建脚本生成 arm64 应用。

```sh
zsh build.sh
```

输出：`build/Clear Bar.app`。脚本会生成图标并进行本地签名。`AppIcon.png` 是图标原图；`make_icns.py` 只把各尺寸 PNG 封装成 ICNS。

## 来源和许可

菜单栏混合方法参考 [zorth64/ClearMenuBar](https://github.com/zorth64/ClearMenuBar) 1.2 的实现。本项目是本地衍生实现，加入多屏管理、统一壁纸库和紧凑面板，并非原作者发布的官方版本。

源码按 **GPL-3.0-or-later** 提供，见 [LICENSE](LICENSE) 和 [NOTICE.md](NOTICE.md)。
